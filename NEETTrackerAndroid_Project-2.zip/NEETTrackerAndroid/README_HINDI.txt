NEET Tracker Android app project
================================

Yeh Android Studio project hai. App phone par install hone wali APK banata hai; Chrome/PWA install ki zaroorat nahi. Aapka existing NEET Tracker HTML app ke andar bundle hai, isliye internet ke bina bhi main tracker chal sakta hai. Google Fonts ke liye internet ho to font load ho sakta hai.

APK banane ka tareeqa:
1. PC/laptop par Android Studio install karein.
2. Android Studio > Open > is folder ko select karein.
3. Android SDK Platform 35 aur Android Build Tools install hone dein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK aam taur par app/build/outputs/apk/debug/app-debug.apk par milegi.
6. APK phone par bhejein, open karein, aur Android prompt par “Install unknown apps” allow karke install karein.

Important:
- Is environment mein Android SDK/Gradle build tool installed nahi hai aur external downloads blocked hain, isliye yahan compiled APK produce/verify nahi kar sakta. Yeh ready-to-open source project hai, APK file nahi.
- Progress app ke local WebView storage mein save hota hai. Uninstall/data clear karne se pehle Backup lo.
